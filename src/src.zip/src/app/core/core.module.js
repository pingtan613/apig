(function() {
	'use strict';

	angular.module('app.core', [
		//Angular Modules
		'ngRoute', 'ngSanitize', 'ui.select'
	]);
})();

