(function() {
	'use strict';

	angular.module('app', [

	'app.core',
	'app.service',
	'app.client',
	'app.wsdl',
	'app.sla',
	'app.user'

	]);

	

})();